# LCD Hello World Example
Using:
- U8G2 Arduino Library
- NHD-C12864A1Z-FSW-FBW-HTT LCD (ST7565P SPI controller)
- SW SPI
<br/>
HW SPI needs further research. Current broken implementation causes a bunch of scattered pixels throughout the screen.
<br/>


